from PIL import Image, ImageDraw
from pathlib import Path
for size in (192,512):
 im=Image.new('RGB',(size,size),'#141e2a');d=ImageDraw.Draw(im)
 box=(size*.25,size*.25,size*.75,size*.75)
 d.ellipse(box,fill='#c7e8de');d.pieslice(box,180,360,fill='#658296')
 im.save(Path('public')/f'icon-{size}.png')
