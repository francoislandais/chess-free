import { writeFile, readFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root = 'dist/client';
await readFile(path.join(root, 'index.html'));
// Version each shell by the actual build, keeping old clients on the old worker.
const digest = createHash('sha256');
async function walk(dir) {
  for (const name of (await readdir(dir, { withFileTypes: true })).sort(
    (a, b) => a.name.localeCompare(b.name),
  )) {
    const p = path.join(dir, name.name);
    if (name.isDirectory()) await walk(p);
    else if (name.name !== 'sw.js') digest.update(await readFile(p));
  }
}
await walk(root);
const worker = await readFile('public/sw.js', 'utf8');
await writeFile(
  path.join(root, 'sw.js'),
  worker.replace(
    'calme-shell-v1',
    'calme-shell-' + digest.digest('hex').slice(0, 12),
  ),
);
await writeFile(path.join(root, '.nojekyll'), '');
console.log('PWA statique prête dans dist/client.');
