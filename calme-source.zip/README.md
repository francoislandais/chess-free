# Calme — Échecs

PWA personnelle pour jouer des parties rapides sur Lichess dans une interface sans nom, Elo, avatar ou chat adverse. Aucun moteur d’analyse. Les adversaires peuvent toujours voir votre compte sur Lichess.

## Première version

- Connexion Lichess OAuth PKCE, portée minimale `board:play`, aucun secret client.
- Autorisation conservée dans `sessionStorage`, jamais dans le dépôt ou le cache PWA. Une nouvelle session/appareil peut nécessiter une nouvelle connexion.
- Recherche standard 10+0, 10+5 et 15+10, classée ou amicale.
- Échiquier tactile et clavier : choisir une pièce puis une case. Promotions explicites, roque, prise en passant, coups légaux via chess.js. Essai local à deux joueurs, sans adversaire automatique.
- Orientation automatique, pendules recalées sur Lichess, reprise des parties actives, téléchargement PGN anonymisé après partie.
- Flux NDJSON surveillés, reconnexion progressive, respect des réponses 429, pas de renvoi automatique d’un coup incertain. La position Lichess est la source de vérité.
- Verrou exclusif entre onglets d’un même navigateur. **Ce verrou ne synchronise pas deux appareils** : utiliser un seul appareil de jeu à la fois.
- Messages et propositions adverses non affichés. Le bouton de nulle peut accepter une offre en attente ; une confirmation le précise.
- PWA HTTPS avec cache du shell uniquement et mises à jour différées tant que l’ancienne application est ouverte.

## Développement

Node 24 et pnpm 11.19.0.

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm run dev
pnpm run check
pnpm run test
pnpm run build
```

Le site exporté est dans `dist/client`. Aucun serveur applicatif ni Raspberry nécessaire. L’installation PWA est désactivée sur localhost pour ne pas gêner le développement.

## GitHub Pages

1. Placer ce projet dans le dépôt choisi, branche `main`.
2. Dans Settings → Pages, choisir GitHub Actions comme source.
3. Le workflow `.github/workflows/pages.yml` vérifie et publie le projet.
4. Ouvrir l’adresse HTTPS et se connecter à Lichess depuis ce domaine. Le retour OAuth utilise exactement l’adresse courante.

Le workflow configure automatiquement le préfixe du dépôt. Pour tester un chemin de projet localement : `BASE_PATH=/chess pnpm run build`.

## Validation et limites de la V1

Tests automatisés : règles spéciales, filtrage des données sociales, découpage du flux, coup incertain, double envoi et blocage pendant la reconnexion. Compilation TypeScript et export statique vérifiés.

À valider avec le propriétaire avant un usage classé régulier : OAuth réel, première partie amicale complète, passage Wi-Fi/mobile, écran verrouillé puis reprise, retour après rechargement, installation iOS/Android et publication dans le dépôt réel. Aucun compte n’a été utilisé pour lancer une partie pendant la construction. Les tests utilisent des réponses simulées ; ils ne prouvent pas la fiabilité du réseau Lichess en conditions réelles.

Les pendules affichées sont des estimations interpolées à partir du dernier état ; Lichess détermine le temps et le résultat. Le système mobile peut suspendre l’application en arrière-plan, sans arrêter la pendule. Pas de prémouvement, glisser-déposer ou réclamation automatique de victoire dans cette V1.

L’interface masque les données sociales ; il ne s’agit pas d’un anonymat réseau : l’API transmet des identités, que l’application écarte, et les parties restent visibles sur Lichess.

WebMCP optionnel : lecture de l’état de connexion uniquement, sans position ni coups ni commandes de jeu. Ce contrat n’a pas été exécuté dans un navigateur compatible WebMCP.

## Sources

- API : https://lichess.org/api
- Exemple officiel : https://github.com/lichess-org/api-demo
- Règles : chess.js, licence BSD-2-Clause.
- Pièces Cburnett par Colin M. L. Burnett, GPL-2.0-or-later. Sources SVG et licence dans `public/pieces`.
