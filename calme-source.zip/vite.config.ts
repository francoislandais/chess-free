import tailwindcss from '@tailwindcss/postcss';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import path from 'node:path';
export default defineConfig({
  base: (process.env.BASE_PATH || '') + '/',
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname) } },
  css: { postcss: { plugins: [tailwindcss()] } },
  server: {
    host: '127.0.0.1',
    port: 3000,
    strictPort: true,
    watch: { useFsEvents: false, usePolling: true },
  },
  build: { outDir: 'dist/client' },
});
