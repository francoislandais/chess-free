# Publication du 11 septembre 2026

Dépôt : https://github.com/francoislandais/chess-free
Site : https://francoislandais.github.io/chess-free/

L’accès Git HTTPS enregistré sur le Mac renvoie HTTP 403 pour l’écriture. La publication initiale a donc été réalisée depuis la session GitHub connectée dans Chrome, sans modifier de credential.

Le `main` distant contient la version compilée à plat et une archive `calme-source.zip` du source complet au commit local `ede0edf`. GitHub Pages sert la racine de `main` (Deploy from a branch). Le commit distant initial est `522d1de5a72ae3799b53be9de070788192fd1138`.

Attention : le `main` local est le source, le `main` distant est la distribution. **Ne pas forcer un push ni fusionner aveuglément ces historiques différents.** Une fois l’accès Git rétabli, publier le source sur une branche dédiée puis configurer GitHub Actions, ou convenir d’une migration explicite.

Préparation de la distribution plate : build avec `BASE_PATH=/chess-free`, fichiers `dist/client/assets/*` déplacés à la racine et références `/chess-free/assets/` remplacées par `./`; fichiers `dist/client/pieces/*` renommés `piece-*` et références `./pieces/` remplacées par `./piece-`. Les icônes, le manifeste et le service worker restent à la racine. Le dossier temporaire de publication est `/private/tmp/calme-pages`.

Validation avant publication : compilation TypeScript, 12 tests automatisés, références de scripts/styles et 12 pièces vérifiées. OAuth réel, partie amicale complète et tests mobiles restent à effectuer avec le propriétaire. Aucun coup réel n’a été joué pendant la construction.

## Mise à jour mobile

Échiquier élargi en portrait, commandes secondaires dans un menu, pendules à droite en paysage. Suppression de la reconnexion systématique après un coup confirmé par HTTP ; récupération après 5 secondes si la confirmation de position manque. Compilation TypeScript et 14 tests réussis. La connexion et une partie réelle ont été validées par le propriétaire avant cette mise à jour ; le rendu sur appareil mobile physique reste à vérifier.
