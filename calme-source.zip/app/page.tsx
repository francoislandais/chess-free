'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { type Square } from 'chess.js';
import {
  ArrowUpRight,
  ShieldCheck,
  Circle,
  RotateCcw,
  Flag,
  Maximize,
  Download,
  LogOut,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription,
} from '@/components/ui/alert-dialog';
import { RadioGroup as BaseRadioGroup } from '@base-ui/react/radio-group';
import { Radio } from '@base-ui/react/radio';
import {
  LichessClient,
  login,
  restoreToken,
  forgetToken,
  type Snapshot,
} from '@/lib/lichess';
import { replay, activeStatus, resultText, clockText } from '@/lib/chess';
const names: Record<string, string> = {
  k: 'roi',
  q: 'dame',
  r: 'tour',
  b: 'fou',
  n: 'cavalier',
  p: 'pion',
};
const cadences = [
  { time: 10, inc: 0 },
  { time: 10, inc: 5 },
  { time: 15, inc: 10 },
];
const empty: Snapshot = {
  connected: false,
  ready: false,
  searching: false,
  syncing: false,
  pending: false,
  error: '',
};
type InstallEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
};
export default function Home() {
  const [cadence, setCadence] = useState(2),
    [rated, setRated] = useState(true),
    [snapshot, setSnapshot] = useState<Snapshot>(empty),
    [demo, setDemo] = useState(false),
    [demoMoves, setDemoMoves] = useState(''),
    [selected, setSelected] = useState<Square | null>(null),
    [promotion, setPromotion] = useState<{ from: Square; to: Square } | null>(
      null,
    ),
    [confirm, setConfirm] = useState<'resign' | 'abort' | 'draw/yes' | null>(
      null,
    ),
    [connectOpen, setConnectOpen] = useState(false),
    [installOpen, setInstallOpen] = useState(false),
    [busy, setBusy] = useState(true),
    [tick, setTick] = useState(0),
    [online, setOnline] = useState(true),
    [hints, setHints] = useState(true),
    [flipped, setFlipped] = useState(false),
    [install, setInstall] = useState<InstallEvent | null>(null),
    [localError, setLocalError] = useState('');
  const client = useRef<LichessClient | null>(null),
    playArea = useRef<HTMLDivElement>(null),
    actionLatch = useRef(false);
  useEffect(() => {
    let cancelled = false;
    let instance: LichessClient | undefined;
    void restoreToken()
      .then((token) => {
        if (cancelled) return;
        if (token) {
          instance = new LichessClient(token, setSnapshot);
          client.current = instance;
          void instance.start();
        }
        setBusy(false);
      })
      .catch((e) => {
        if (!cancelled) {
          setLocalError(e.message);
          setBusy(false);
        }
      });
    const network = () => {
      setOnline(navigator.onLine);
      if (navigator.onLine) client.current?.reconnect();
    };
    const visible = () => {
      if (document.visibilityState === 'visible') client.current?.reconnect();
    };
    const before = (e: BeforeUnloadEvent) => {
      const state = client.current?.value;
      if (
        state?.searching ||
        (state?.game && activeStatus(state.game.state.status))
      ) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    const installer = (e: Event) => {
      e.preventDefault();
      setInstall(e as InstallEvent);
    };
    setOnline(navigator.onLine);
    window.addEventListener('online', network);
    window.addEventListener('offline', network);
    document.addEventListener('visibilitychange', visible);
    window.addEventListener('beforeunload', before);
    window.addEventListener('beforeinstallprompt', installer);
    if (
      'serviceWorker' in navigator &&
      location.hostname !== '127.0.0.1' &&
      location.hostname !== 'localhost'
    )
      void navigator.serviceWorker.register('./sw.js').catch(() => {});
    const timer = setInterval(() => setTick(performance.now()), 200);
    return () => {
      cancelled = true;
      instance?.close();
      client.current = null;
      clearInterval(timer);
      window.removeEventListener('online', network);
      window.removeEventListener('offline', network);
      document.removeEventListener('visibilitychange', visible);
      window.removeEventListener('beforeunload', before);
      window.removeEventListener('beforeinstallprompt', installer);
    };
  }, []);
  const game = snapshot.game;
  const active = !!game && activeStatus(game.state.status);
  useEffect(() => {
    if (!active || !('wakeLock' in navigator)) return;
    let released = false;
    let lock: WakeLockSentinel | undefined;
    const acquire = () => {
      if (document.visibilityState !== 'visible') return;
      void navigator.wakeLock
        .request('screen')
        .then((value) => {
          if (released) void value.release();
          else lock = value;
        })
        .catch(() => {});
    };
    acquire();
    document.addEventListener('visibilitychange', acquire);
    return () => {
      released = true;
      void lock?.release();
      document.removeEventListener('visibilitychange', acquire);
    };
  }, [active]);
  const playing = active || demo;
  const moves = demo ? demoMoves : (game?.state.moves ?? '');
  const board = useMemo(
    () => replay(moves, demo ? 'startpos' : game?.initialFen),
    [moves, demo, game?.initialFen],
  );
  const orientation = (game?.color === 'black') !== flipped ? 'black' : 'white';
  const squares = Array.from(
    { length: 64 },
    (_, i) =>
      `${'abcdefgh'[orientation === 'white' ? i % 8 : 7 - (i % 8)]}${orientation === 'white' ? 8 - Math.floor(i / 8) : Math.floor(i / 8) + 1}` as Square,
  );
  const canMove = demo
    ? !board.isGameOver()
    : active &&
      online &&
      !snapshot.syncing &&
      !snapshot.pending &&
      board.turn() === game?.color[0];
  const legal =
    selected && canMove ? board.moves({ square: selected, verbose: true }) : [];
  useEffect(() => {
    setSelected(null);
    setPromotion(null);
    actionLatch.current = false;
  }, [moves, game?.id, demo]);
  useEffect(() => {
    if (!canMove) {
      setSelected(null);
      setPromotion(null);
    }
  }, [canMove]);
  useEffect(() => {
    if (game) {
      setDemo(false);
      setFlipped(false);
    }
  }, [game?.id]);
  // Agents may inspect connection health, but cannot inspect positions or play moves.
  useEffect(() => {
    const context = (
      document as unknown as {
        modelContext?: {
          registerTool: (tool: unknown, options: unknown) => Promise<void>;
        };
      }
    ).modelContext;
    if (!context) return;
    const lifecycle = new AbortController();
    try {
      void Promise.resolve(
        context.registerTool(
          {
            name: 'read_calme_connection',
            description:
              'Read connection health only; no chess position, moves or player data.',
            inputSchema: {
              type: 'object',
              properties: {},
              additionalProperties: false,
            },
            annotations: { readOnlyHint: true },
            execute: (input: unknown) => {
              if (
                !input ||
                typeof input !== 'object' ||
                Object.keys(input).length
              )
                throw new Error('No arguments expected');
              const s = client.current?.value;
              return {
                connected: !!s?.connected,
                ready: !!s?.ready,
                reconnecting: !!s?.syncing,
              };
            },
          },
          { signal: lifecycle.signal },
        ),
      ).catch(() => {});
    } catch {}
    return () => lifecycle.abort();
  }, []);
  const play = (from: Square, to: Square, promote?: string) => {
    if (!canMove || actionLatch.current) return;
    actionLatch.current = true;
    setSelected(null);
    setPromotion(null);
    if (demo) {
      try {
        const test = replay(demoMoves);
        test.move({ from, to, promotion: promote });
        setDemoMoves((demoMoves + ' ' + from + to + (promote ?? '')).trim());
      } catch {
        actionLatch.current = false;
      }
    } else {
      void client.current?.move(from + to + (promote ?? '')).finally(() => {
        actionLatch.current = false;
      });
    }
  };
  const choose = (square: Square) => {
    if (!canMove) return;
    const candidates = legal.filter((m) => m.to === square);
    if (selected && candidates.length) {
      if (candidates.some((m) => m.promotion))
        setPromotion({ from: selected, to: square });
      else play(selected, square);
      return;
    }
    setSelected(
      board.get(square)?.color === board.turn()
        ? selected === square
          ? null
          : square
        : null,
    );
  };
  const startDemo = () => {
    if (active || snapshot.searching) return;
    setDemo(true);
    setDemoMoves('');
    setFlipped(false);
    setSelected(null);
    setLocalError('');
  };
  const search = () => {
    setDemo(false);
    setFlipped(false);
    const c = cadences[cadence];
    void client.current?.search(c.time, c.inc, rated);
  };
  const disconnect = () => {
    client.current?.close();
    client.current = null;
    forgetToken();
    setSnapshot(empty);
    setLocalError('');
  };
  const doLogin = () => {
    setBusy(true);
    void login().catch(() => {
      setBusy(false);
      setLocalError('Impossible de commencer la connexion. Réessayez.');
    });
  };
  const clock = (color: 'white' | 'black') => {
    if (!game || demo) return clockText(cadences[cadence].time * 60000);
    let time = color === 'white' ? game.state.wtime : game.state.btime;
    const running =
      active && board.turn() === color[0] && board.history().length >= 2;
    if (running) time -= Math.max(0, tick - game.received);
    return clockText(time);
  };
  const status = demo
    ? board.isCheckmate()
      ? 'Échec et mat.'
      : board.isDraw()
        ? 'Partie nulle.'
        : `${board.turn() === 'w' ? 'Aux blancs' : 'Aux noirs'} de jouer${board.isCheck() ? ' · Échec' : ''} · Essai local`
    : !online
      ? 'Hors connexion — les coups sont suspendus.'
      : snapshot.syncing
        ? 'Reconnexion — vérification de la position…'
        : snapshot.pending
          ? 'Confirmation du coup…'
          : active
            ? `${canMove ? 'À vous de jouer' : 'Au tour des ' + (game?.color === 'white' ? 'noirs' : 'blancs')}${board.isCheck() ? ' · Échec' : ''}`
            : game
              ? resultText(game.state, game.color)
              : snapshot.searching
                ? 'Recherche d’une partie…'
                : 'Choisissez votre cadence pour commencer.';
  const topColor = orientation === 'white' ? 'black' : 'white';
  const bottomColor = topColor === 'white' ? 'black' : 'white';
  const last = board.history({ verbose: true }).at(-1);
  const error = localError || snapshot.error;
  const expiration =
    active && game?.state.expiration
      ? Math.max(
          0,
          Math.ceil(
            (game.state.expiration.millisToMove -
              game.state.expiration.idleMillis -
              Math.max(0, tick - game.received)) /
              1000,
          ),
        )
      : null;
  const exportPgn = () => {
    const copy = replay(moves, game?.initialFen);
    copy.header('Event', 'Calme', 'White', 'Blancs', 'Black', 'Noirs');
    if (game && !activeStatus(game.state.status))
      copy.header(
        'Result',
        game.state.winner === 'white'
          ? '1-0'
          : game.state.winner === 'black'
            ? '0-1'
            : game.state.status === 'aborted'
              ? '*'
              : '1/2-1/2',
      );
    const url = URL.createObjectURL(
      new Blob([copy.pgn()], { type: 'application/x-chess-pgn' }),
    );
    const a = document.createElement('a');
    a.href = url;
    a.download = 'calme-partie.pgn';
    a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <main>
      <header>
        <a
          className="brand"
          href="./"
          onClick={(e) => {
            if (playing || snapshot.searching) e.preventDefault();
          }}
        >
          <span className="brand-mark">◒</span> calme
          <span className="brand-detail">ÉCHECS</span>
        </a>
        <div
          className={'connection ' + (snapshot.ready && online ? 'live' : '')}
        >
          <i />
          {!online
            ? 'Hors ligne'
            : snapshot.ready
              ? 'Lichess connecté'
              : snapshot.connected
                ? 'Connexion…'
                : 'Votre espace zen'}
          {!active && !snapshot.searching && (
            <button
              className="icon-button install"
              title="Installer Calme"
              aria-label="Installer Calme"
              onClick={() =>
                install ? void install.prompt() : setInstallOpen(true)
              }
            >
              <Download size={16} />
            </button>
          )}
        </div>
      </header>
      <section className={'workspace ' + (playing ? 'in-game' : '')}>
        <aside>
          <div className="eyebrow">LE TEMPS DE JOUER</div>
          <h1>
            {active ? (
              'La partie.'
            ) : demo ? (
              'À votre rythme.'
            ) : (
              <>
                À vous
                <br />
                de jouer.
              </>
            )}
          </h1>
          <p className="intro">
            Un échiquier. Du temps.
            <br />
            Rien entre vous et la partie.
          </p>
          <div className="setup">
            {!active && (
              <>
                <h2 id="cadence-label">Votre cadence</h2>
                <BaseRadioGroup
                  aria-labelledby="cadence-label"
                  value={String(cadence)}
                  onValueChange={(value) => setCadence(Number(value))}
                  disabled={snapshot.searching}
                  className="cadences"
                >
                  {cadences.map((c, i) => (
                    <Radio.Root
                      key={i}
                      value={String(i)}
                      className={cadence === i ? 'chosen' : ''}
                    >
                      {c.time} + {c.inc}
                    </Radio.Root>
                  ))}
                </BaseRadioGroup>
                <p className="hint">Minutes + secondes par coup</p>
                <label className="check-label">
                  <Checkbox
                    checked={rated}
                    onCheckedChange={setRated}
                    disabled={snapshot.searching}
                  />{' '}
                  Partie classée
                </label>
                <div className="rated">
                  <ShieldCheck size={18} />{' '}
                  {rated
                    ? 'Votre classement évolue sur Lichess.'
                    : 'Partie amicale, sans effet sur le classement.'}
                </div>
                {snapshot.searching ? (
                  <button
                    className="primary"
                    onClick={() => client.current?.cancel()}
                  >
                    Annuler la recherche
                  </button>
                ) : snapshot.ready ? (
                  <button
                    className="primary"
                    disabled={!online}
                    onClick={search}
                  >
                    Trouver une partie <ArrowUpRight size={19} />
                  </button>
                ) : (
                  <button
                    className="primary"
                    disabled={busy || !online || snapshot.connected}
                    onClick={() => setConnectOpen(true)}
                  >
                    {busy
                      ? 'Préparation…'
                      : snapshot.connected
                        ? 'Connexion en cours…'
                        : 'Connexion Lichess'}{' '}
                    <ArrowUpRight size={19} />
                  </button>
                )}
                {!snapshot.searching && (
                  <button
                    className="secondary"
                    onClick={demo ? () => setDemo(false) : startDemo}
                  >
                    {demo ? 'Quitter l’essai' : 'Essayer l’échiquier'}
                  </button>
                )}
                {snapshot.connected && !snapshot.searching && (
                  <button className="small-link" onClick={disconnect}>
                    <LogOut
                      size={12}
                      style={{ display: 'inline', marginRight: 6 }}
                    />
                    Déconnecter ce compte
                  </button>
                )}
              </>
            )}
            {active && (
              <>
                <div className="rated">
                  <ShieldCheck size={18} /> Rapide ·{' '}
                  {game?.rated ? 'Classée' : 'Amicale'}
                </div>
                <p className="status-text">
                  Vous jouez les {game?.color === 'white' ? 'blancs' : 'noirs'}.
                </p>
              </>
            )}
          </div>
          {playing && (
            <div className="game-actions">
              {demo ? (
                <>
                  <button
                    className="icon-button"
                    onClick={() => setDemoMoves('')}
                  >
                    <RotateCcw size={15} />
                    Recommencer
                  </button>
                  <button
                    className="icon-button"
                    onClick={() => setDemo(false)}
                  >
                    Quitter l’essai
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="icon-button"
                    disabled={snapshot.pending || snapshot.syncing || !online}
                    onClick={() => setConfirm('resign')}
                  >
                    <Flag size={15} />
                    Abandonner
                  </button>
                  {board.history().length < 2 && (
                    <button
                      className="icon-button"
                      disabled={snapshot.pending || snapshot.syncing || !online}
                      onClick={() => setConfirm('abort')}
                    >
                      Annuler la partie
                    </button>
                  )}
                  <button
                    className="icon-button"
                    disabled={snapshot.pending || snapshot.syncing || !online}
                    onClick={() => setConfirm('draw/yes')}
                  >
                    Proposer nulle
                  </button>
                </>
              )}
            </div>
          )}
          {!active && game && !demo && (
            <button className="secondary" onClick={exportPgn}>
              Enregistrer la partie
            </button>
          )}
          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}
          {snapshot.searching && (
            <p className="status-text" role="status">
              Recherche en cours…
              <br />
              Gardez l’application ouverte.
            </p>
          )}
          <div className="quiet-note">
            <Circle size={14} />
            <p>
              Ni noms, ni classements, ni messages.
              <br />
              Juste la partie.
            </p>
          </div>
        </aside>
        <div className="play-area" ref={playArea}>
          <div
            className={
              'clock-row ' +
              (playing && board.turn() === topColor[0] ? 'active' : '')
            }
          >
            <span>LES {topColor === 'white' ? 'BLANCS' : 'NOIRS'}</span>
            <strong aria-label={'Temps des ' + topColor}>
              {clock(topColor)}
            </strong>
          </div>
          <div className="board-shell">
            <div
              className="board"
              role="group"
              aria-label="Échiquier. Choisissez une pièce, puis sa case d’arrivée."
            >
              {squares.map((square, index) => {
                const piece = board.get(square);
                return (
                  <button
                    key={square}
                    onClick={() => choose(square)}
                    aria-label={`${square}${piece ? ', ' + names[piece.type] + ' ' + (piece.color === 'w' ? 'blanc' : 'noir') : ', vide'}`}
                    aria-pressed={selected === square}
                    aria-disabled={!canMove}
                    className={`square ${(Number(square[1]) + square.charCodeAt(0)) % 2 === 0 ? 'dark-square' : 'light-square'} ${piece?.color === 'w' ? 'white-piece' : 'black-piece'} ${selected === square ? 'selected' : ''} ${hints && legal.some((m) => m.to === square) ? 'legal' : ''} ${last && (last.from === square || last.to === square) ? 'last' : ''}`}
                  >
                    {piece && (
                      <img
                        aria-hidden="true"
                        alt=""
                        draggable={false}
                        className="piece"
                        src={`./pieces/${piece.color}${piece.type.toUpperCase()}.svg`}
                      />
                    )}
                    {index % 8 === 0 && (
                      <small aria-hidden="true" className="rank">
                        {square[1]}
                      </small>
                    )}
                    {index >= 56 && (
                      <small aria-hidden="true" className="file">
                        {square[0]}
                      </small>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
          <div
            className={
              'clock-row bottom ' +
              (playing && board.turn() === bottomColor[0] ? 'active' : '')
            }
          >
            <span>LES {bottomColor === 'white' ? 'BLANCS' : 'NOIRS'}</span>
            <strong>{clock(bottomColor)}</strong>
          </div>
          <div className="board-footer">
            <span role="status" aria-live="polite">
              {status}
            </span>
            <button
              className="icon-button"
              aria-label="Retourner l’échiquier"
              title="Retourner l’échiquier"
              onClick={() => setFlipped(!flipped)}
            >
              <RotateCcw size={16} />
            </button>
            <button
              className="icon-button"
              aria-label="Plein écran"
              title="Plein écran"
              onClick={() => {
                if (document.fullscreenElement) void document.exitFullscreen();
                else
                  void playArea.current
                    ?.requestFullscreen?.()
                    .catch(() =>
                      setLocalError(
                        'Le plein écran n’est pas disponible dans ce navigateur.',
                      ),
                    );
              }}
            >
              <Maximize size={16} />
            </button>
          </div>
          {expiration !== null && (
            <p className="status-text">
              Premier coup à jouer dans {expiration} s.
            </p>
          )}
          {playing && (
            <label className="check-label">
              <Checkbox checked={hints} onCheckedChange={setHints} /> Afficher
              les déplacements possibles
            </label>
          )}
        </div>
      </section>
      <footer>
        <span>calme — votre espace de jeu</span>
        <span>Interface indépendante · Parties sur Lichess</span>
      </footer>
      <Dialog open={connectOpen} onOpenChange={setConnectOpen}>
        <DialogContent className="dialog-card">
          <DialogTitle>Votre compte, votre partie.</DialogTitle>
          <DialogDescription>
            Connectez votre compte sur Lichess, puis revenez ici pour jouer.
            Calme ne vous demande jamais votre mot de passe. Votre autorisation
            reste dans cette session du navigateur.
          </DialogDescription>
          <button className="primary" onClick={doLogin} disabled={busy}>
            Continuer sur Lichess <ArrowUpRight size={18} />
          </button>
          <p className="hint">
            Votre adversaire peut toujours voir votre compte sur Lichess.
          </p>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!promotion}
        onOpenChange={(open) => {
          if (!open) setPromotion(null);
        }}
      >
        <DialogContent className="dialog-card">
          <DialogTitle>Promouvoir le pion</DialogTitle>
          <DialogDescription>
            Choisissez votre nouvelle pièce.
          </DialogDescription>
          <div className="promotions">
            {['q', 'r', 'b', 'n'].map((p) => (
              <button
                className="secondary"
                aria-label={names[p]}
                key={p}
                onClick={() => {
                  if (promotion) play(promotion.from, promotion.to, p);
                }}
              >
                <img
                  alt=""
                  src={`./pieces/${board.turn()}${p.toUpperCase()}.svg`}
                />
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
      <AlertDialog
        open={!!confirm}
        onOpenChange={(open) => {
          if (!open) setConfirm(null);
        }}
      >
        <AlertDialogContent className="dialog-card">
          <AlertDialogTitle>
            {confirm === 'resign'
              ? 'Abandonner cette partie ?'
              : confirm === 'abort'
                ? 'Annuler cette partie ?'
                : 'Proposer une partie nulle ?'}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {confirm === 'resign'
              ? 'La partie sera perdue. Cette action est définitive.'
              : confirm === 'abort'
                ? 'Lichess acceptera l’annulation si la partie vient de commencer.'
                : 'Lichess transmettra la proposition. Si une proposition adverse est en attente, cette action l’accepte et termine la partie.'}
          </AlertDialogDescription>
          <button
            className="primary"
            disabled={
              !active || snapshot.pending || snapshot.syncing || !online
            }
            onClick={() => {
              if (confirm) void client.current?.action(confirm);
              setConfirm(null);
            }}
          >
            Confirmer
          </button>
          <button className="secondary" onClick={() => setConfirm(null)}>
            Continuer à jouer
          </button>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog open={installOpen} onOpenChange={setInstallOpen}>
        <DialogContent className="dialog-card">
          <DialogTitle>Calme, à portée de main.</DialogTitle>
          <DialogDescription>
            Sur iPhone : ouvrez le site dans Safari, puis Partager → Sur l’écran
            d’accueil. Sur Android : menu du navigateur → Installer
            l’application. Sur ordinateur : utilisez l’icône d’installation dans
            la barre d’adresse, si elle est proposée.
          </DialogDescription>
          <p className="hint">
            L’installation sera disponible depuis l’adresse HTTPS publiée. Une
            connexion Internet reste nécessaire pour jouer.
          </p>
        </DialogContent>
      </Dialog>
    </main>
  );
}
