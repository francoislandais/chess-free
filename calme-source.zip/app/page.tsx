'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { type Square } from 'chess.js';
import { Play, X, Check, Flag, Handshake, LogIn, LogOut, RotateCcw, FlaskConical, Trophy, LoaderCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import {
  LichessClient,
  login,
  restoreToken,
  forgetToken,
  type Snapshot,
} from '@/lib/lichess';
import { replay, activeStatus, clockText } from '@/lib/chess';
const names: Record<string, string> = {
  k: 'roi',
  q: 'dame',
  r: 'tour',
  b: 'fou',
  n: 'cavalier',
  p: 'pion',
};
const cadences = [
  { time: 10, inc: 0 },
  { time: 10, inc: 5 },
  { time: 15, inc: 10 },
];
const empty: Snapshot = {
  connected: false,
  ready: false,
  searching: false,
  syncing: false,
  pending: false,
  error: '',
};
export default function Home() {
  const [cadence, setCadence] = useState(2),
    [rated, setRated] = useState(true),
    [snapshot, setSnapshot] = useState<Snapshot>(empty),
    [demo, setDemo] = useState(false),
    [demoMoves, setDemoMoves] = useState(''),
    [selected, setSelected] = useState<Square | null>(null),
    [promotion, setPromotion] = useState<{ from: Square; to: Square } | null>(
      null,
    ),
    [confirm, setConfirm] = useState<'resign' | 'abort' | 'draw/yes' | null>(
      null,
    ),
    [dismissedGame, setDismissedGame] = useState<string | null>(null),
    [busy, setBusy] = useState(true),
    [tick, setTick] = useState(0),
    [online, setOnline] = useState(true),
    [flipped, setFlipped] = useState(false),
    [localError, setLocalError] = useState('');
  const client = useRef<LichessClient | null>(null),
    actionLatch = useRef(false);
  useEffect(() => {
    let cancelled = false;
    let instance: LichessClient | undefined;
    void restoreToken()
      .then((token) => {
        if (cancelled) return;
        if (token) {
          instance = new LichessClient(token, setSnapshot);
          client.current = instance;
          void instance.start();
        }
        setBusy(false);
      })
      .catch((e) => {
        if (!cancelled) {
          setLocalError(e.message);
          setBusy(false);
        }
      });
    const network = () => {
      setOnline(navigator.onLine);
      if (navigator.onLine) client.current?.reconnect();
    };
    const visible = () => {
      if (document.visibilityState === 'visible') client.current?.reconnect();
    };
    setOnline(navigator.onLine);
    window.addEventListener('online', network);
    window.addEventListener('offline', network);
    document.addEventListener('visibilitychange', visible);
    if (
      'serviceWorker' in navigator &&
      location.hostname !== '127.0.0.1' &&
      location.hostname !== 'localhost'
    )
      void navigator.serviceWorker.register('./sw.js').catch(() => {});
    const timer = setInterval(() => setTick(performance.now()), 200);
    return () => {
      cancelled = true;
      instance?.close();
      client.current = null;
      clearInterval(timer);
      window.removeEventListener('online', network);
      window.removeEventListener('offline', network);
      document.removeEventListener('visibilitychange', visible);
    };
  }, []);
  const game = snapshot.game;
  const active = !!game && activeStatus(game.state.status);
  useEffect(() => {
    if (!active || !('wakeLock' in navigator)) return;
    let released = false;
    let lock: WakeLockSentinel | undefined;
    const acquire = () => {
      if (document.visibilityState !== 'visible') return;
      void navigator.wakeLock
        .request('screen')
        .then((value) => {
          if (released) void value.release();
          else lock = value;
        })
        .catch(() => {});
    };
    acquire();
    document.addEventListener('visibilitychange', acquire);
    return () => {
      released = true;
      void lock?.release();
      document.removeEventListener('visibilitychange', acquire);
    };
  }, [active]);
  const playing = demo || active || (!!game && game.id !== dismissedGame && !snapshot.searching);
  const moves = demo ? demoMoves : (game?.state.moves ?? '');
  const board = useMemo(
    () => replay(moves, demo ? 'startpos' : game?.initialFen),
    [moves, demo, game?.initialFen],
  );
  const orientation = (game?.color === 'black') !== flipped ? 'black' : 'white';
  const squares = Array.from(
    { length: 64 },
    (_, i) =>
      `${'abcdefgh'[orientation === 'white' ? i % 8 : 7 - (i % 8)]}${orientation === 'white' ? 8 - Math.floor(i / 8) : Math.floor(i / 8) + 1}` as Square,
  );
  const canMove = demo
    ? !board.isGameOver()
    : active &&
      online &&
      !snapshot.syncing &&
      !snapshot.pending &&
      board.turn() === game?.color[0];
  const legal =
    selected && canMove ? board.moves({ square: selected, verbose: true }) : [];
  useEffect(() => {
    setSelected(null);
    setPromotion(null);
    actionLatch.current = false;
  }, [moves, game?.id, demo]);
  useEffect(() => {
    if (!canMove) {
      setSelected(null);
      setPromotion(null);
    }
  }, [canMove]);
  useEffect(() => {
    if (game) {
      setDemo(false);
      setFlipped(false);
    }
  }, [game?.id]);
  // Agents may inspect connection health, but cannot inspect positions or play moves.
  useEffect(() => {
    const context = (
      document as unknown as {
        modelContext?: {
          registerTool: (tool: unknown, options: unknown) => Promise<void>;
        };
      }
    ).modelContext;
    if (!context) return;
    const lifecycle = new AbortController();
    try {
      void Promise.resolve(
        context.registerTool(
          {
            name: 'read_calme_connection',
            description:
              'Read connection health only; no chess position, moves or player data.',
            inputSchema: {
              type: 'object',
              properties: {},
              additionalProperties: false,
            },
            annotations: { readOnlyHint: true },
            execute: (input: unknown) => {
              if (
                !input ||
                typeof input !== 'object' ||
                Object.keys(input).length
              )
                throw new Error('No arguments expected');
              const s = client.current?.value;
              return {
                connected: !!s?.connected,
                ready: !!s?.ready,
                reconnecting: !!s?.syncing,
              };
            },
          },
          { signal: lifecycle.signal },
        ),
      ).catch(() => {});
    } catch {}
    return () => lifecycle.abort();
  }, []);
  const play = (from: Square, to: Square, promote?: string) => {
    if (!canMove || actionLatch.current) return;
    actionLatch.current = true;
    setSelected(null);
    setPromotion(null);
    if (demo) {
      try {
        const test = replay(demoMoves);
        test.move({ from, to, promotion: promote });
        setDemoMoves((demoMoves + ' ' + from + to + (promote ?? '')).trim());
      } catch {
        actionLatch.current = false;
      }
    } else {
      void client.current?.move(from + to + (promote ?? '')).finally(() => {
        actionLatch.current = false;
      });
    }
  };
  const choose = (square: Square) => {
    if (!canMove) return;
    const candidates = legal.filter((m) => m.to === square);
    if (selected && candidates.length) {
      if (candidates.some((m) => m.promotion))
        setPromotion({ from: selected, to: square });
      else play(selected, square);
      return;
    }
    setSelected(
      board.get(square)?.color === board.turn()
        ? selected === square
          ? null
          : square
        : null,
    );
  };
  const startDemo = () => {
    if (active || snapshot.searching) return;
    setDemo(true);
    setDemoMoves('');
    setFlipped(false);
    setSelected(null);
    setLocalError('');
  };
  const search = () => {
    setDemo(false);
    setFlipped(false);
    const c = cadences[cadence];
    void client.current?.search(c.time, c.inc, rated);
  };
  const disconnect = () => {
    client.current?.close();
    client.current = null;
    forgetToken();
    setSnapshot(empty);
    setLocalError('');
  };
  const doLogin = () => {
    setBusy(true);
    void login().catch(() => {
      setBusy(false);
      setLocalError('Impossible de commencer la connexion. Réessayez.');
    });
  };
  const clock = (color: 'white' | 'black') => {
    if (!game || demo) return clockText(cadences[cadence].time * 60000);
    let time = color === 'white' ? game.state.wtime : game.state.btime;
    const running =
      active && board.turn() === color[0] && board.history().length >= 2;
    if (running) time -= Math.max(0, tick - game.received);
    return clockText(time);
  };
  const topColor = orientation === 'white' ? 'black' : 'white';
  const bottomColor = topColor === 'white' ? 'black' : 'white';
  const last = board.history({ verbose: true }).at(-1);
  const unavailable = !online || snapshot.syncing || snapshot.pending;
  const retry = () => {
    setLocalError('');
    if (client.current) client.current.reconnect();
    else doLogin();
  };
  useEffect(() => { setConfirm(null); }, [game?.id, active, demo]);
  useEffect(() => {
    if (!confirm) return;
    const timer = setTimeout(() => setConfirm(null), 4000);
    return () => clearTimeout(timer);
  }, [confirm]);
  return (
    <main className={playing ? 'game-screen' : 'selection-screen'}>
      {!playing ? (
        <section className="selection" aria-label="Sélection de partie">
          <div className="cadences" role="group" aria-label="Cadence">
            {cadences.map((c, i) => <button key={i} aria-pressed={cadence === i} disabled={snapshot.searching} onClick={() => setCadence(i)}>{c.time} + {c.inc}</button>)}
          </div>
          <div className="selection-controls">
            <button className="control" aria-label="Partie classée" aria-pressed={rated} disabled={snapshot.searching} onClick={() => setRated(!rated)}><Trophy/></button>
            {snapshot.searching ? <button className="control primary" aria-label="Annuler la recherche" onClick={() => client.current?.cancel()}><X/></button>
              : <button className="control primary" aria-label={snapshot.ready ? 'Jouer' : 'Connexion Lichess'} disabled={busy || !online || (snapshot.connected && !snapshot.ready)} onClick={snapshot.ready ? search : doLogin}>{busy || (snapshot.connected && !snapshot.ready) ? <LoaderCircle className="spinning"/> : snapshot.ready ? <Play/> : <LogIn/>}</button>}
            <button className="control" aria-label="Essai local" disabled={snapshot.searching} onClick={startDemo}><FlaskConical/></button>
          </div>
          <div className="selection-tools">
            {snapshot.connected && !snapshot.searching && <button className="control" aria-label="Déconnexion" onClick={disconnect}><LogOut/></button>}
            {(localError || snapshot.error) && <button className="control" aria-label="Réessayer la connexion" disabled={!online} onClick={retry}><RefreshCw/></button>}
          </div>
        </section>
      ) : (
        <section className="game-layout" aria-label="Partie">
          <div className={'clock top ' + (active && board.turn() === topColor[0] ? 'running' : '')} aria-label={'Temps des ' + topColor}>{clock(topColor)}</div>
          <div className="board" role="group" aria-label="Échiquier">
            {squares.map(square => {
              const piece = board.get(square);
              return <button key={square} onClick={() => choose(square)} aria-label={`${square}${piece ? ', ' + names[piece.type] + ' ' + (piece.color === 'w' ? 'blanc' : 'noir') : ', vide'}`} aria-pressed={selected === square} aria-disabled={!canMove}
                className={`square ${(Number(square[1]) + square.charCodeAt(0)) % 2 === 0 ? 'dark-square' : 'light-square'} ${selected === square ? 'selected' : ''} ${legal.some(m => m.to === square) ? 'legal' : ''} ${last && (last.from === square || last.to === square) ? 'last' : ''}`}>
                {piece && <img alt="" draggable={false} className="piece" src={`./pieces/${piece.color}${piece.type.toUpperCase()}.svg`}/>}
              </button>;
            })}
          </div>
          <div className={'clock bottom ' + (active && board.turn() === bottomColor[0] ? 'running' : '')} aria-label={'Temps des ' + bottomColor}>{clock(bottomColor)}</div>
          <div className="game-controls">
            {promotion ? <>
              {['q','r','b','n'].map(p => <button key={p} className="control" aria-label={names[p]} onClick={() => play(promotion.from,promotion.to,p)}><img alt="" src={`./pieces/${board.turn()}${p.toUpperCase()}.svg`}/></button>)}
              <button className="control" aria-label="Annuler la promotion" onClick={() => setPromotion(null)}><X/></button>
            </> : confirm ? <>
              <button className="control confirm" aria-label="Confirmer" disabled={!active || unavailable} onClick={() => {void client.current?.action(confirm); setConfirm(null);}}><Check/></button>
              <button className="control" aria-label="Annuler" onClick={() => setConfirm(null)}><X/></button>
            </> : <>
              {active ? <>
                <button className="control" aria-label="Abandonner" disabled={unavailable} onClick={() => setConfirm('resign')}><Flag/></button>
                <button className="control" aria-label="Proposer ou accepter nulle" disabled={unavailable} onClick={() => setConfirm('draw/yes')}><Handshake/></button>
                {board.history().length < 2 && <button className="control" aria-label="Annuler la partie" disabled={unavailable} onClick={() => setConfirm('abort')}><X/></button>}
              </> : <button className="control" aria-label="Retour à la sélection" onClick={() => {setDemo(false); setDismissedGame(game?.id ?? null);}}><ArrowLeft/></button>}
              <button className="control" aria-label="Retourner l’échiquier" onClick={() => setFlipped(!flipped)}><RotateCcw/></button>
            </>}
          </div>
        </section>
      )}
    </main>
  );
}
