import { useEffect, useState } from 'react';
import { BookOpen, SlidersHorizontal, LoaderCircle, RefreshCw, LogIn, CircleSlash } from 'lucide-react';
import { loadPopular, ratingGroups, squarePoint, type PopularMove } from '@/lib/explorer';
export function useExplorer(fen: string, allowed: boolean, online: boolean) {
  const [enabled,setEnabled]=useState(false), [settings,setSettings]=useState(false);
  const [low,setLow]=useState(0),[high,setHigh]=useState(8),[retry,setRetry]=useState(0);
  const [result,setResult]=useState<{key:string;moves:PopularMove[];state:string}>({key:'',moves:[],state:'idle'});
  const key=fen+'|'+low+'|'+high;
  useEffect(()=>{
    if(!allowed){setEnabled(false);setSettings(false);}
  },[allowed]);
  useEffect(()=>{
    if(!allowed || !enabled || !online) return;
    const abort=new AbortController();
    setResult({key,moves:[],state:'loading'});
    const timeout=setTimeout(()=>abort.abort(),12000);
    const timer=setTimeout(()=>{
      void loadPopular(fen,ratingGroups.slice(low,high+1),abort.signal).then(moves=>{
        if(!abort.signal.aborted) setResult({key,moves,state:moves.length ? 'ready':'empty'});
      }).catch(e=>{
        if(!disposed) setResult({key,moves:[],state:e.message==='auth'?'auth':'error'});
      }).finally(()=>clearTimeout(timeout));
    },250);
    let disposed=false;
    return ()=>{disposed=true;clearTimeout(timer);clearTimeout(timeout);abort.abort();};
  },[allowed,enabled,online,fen,low,high,retry,key]);
  return {enabled,setEnabled,settings,setSettings,low,setLow,high,setHigh,
    refresh:()=>setRetry(n=>n+1),state:!online?'error':result.key===key?result.state:'loading',
    moves:allowed&&enabled&&online&&result.key===key?result.moves:[]};
}
export function ExplorerControls({value:v,onLogin}:{value:ReturnType<typeof useExplorer>;onLogin:()=>void}) {
  return <>
    <button className="control" aria-label="Coups les plus joués" aria-pressed={v.enabled} onClick={()=>v.setEnabled(!v.enabled)}>{v.enabled&&v.state==='loading'?<LoaderCircle className="spinning"/>:v.enabled&&v.state==='empty'?<CircleSlash/>:<BookOpen/>}</button>
    <button className="control" aria-label="Tranche Elo" aria-expanded={v.settings} onClick={()=>v.setSettings(!v.settings)}><SlidersHorizontal/></button>
    {v.enabled&&(v.state==='error'||v.state==='auth')&&<button className="control" aria-label={v.state==='auth'?'Connexion Lichess':'Réessayer les statistiques'} onClick={v.state==='auth'?onLogin:v.refresh}>{v.state==='auth'?<LogIn/>:<RefreshCw/>}</button>}
  </>;
}
export function ExplorerSettings({value:v}:{value:ReturnType<typeof useExplorer>}) {
  return <div className="elo-controls">
    <select aria-label="Elo minimum" value={v.low} onChange={e=>{const n=Number(e.target.value);v.setLow(n);if(n>v.high)v.setHigh(n);}}>{ratingGroups.map((n,i)=><option key={n} value={i}>{n}</option>)}</select>
    <span aria-hidden="true">–</span>
    <select aria-label="Elo maximum" value={v.high} onChange={e=>{const n=Number(e.target.value);v.setHigh(n);if(n<v.low)v.setLow(n);}}>{ratingGroups.map((n,i)=><option key={n} value={i}>{i===8?'∞':ratingGroups[i+1]-1}</option>)}</select>
  </div>;
}
export function ExplorerArrows({moves,black}:{moves:PopularMove[];black:boolean}) {
 const colors=['#f7c65c','#83e4cd','#b6b4ff','#ffa99c'];
 return <svg className="explorer-arrows" viewBox="0 0 800 800" aria-hidden="true">
   <defs>{colors.map((c,i)=><marker key={c} id={'popular-arrow-'+i} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="2.4" markerHeight="2.4" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill={c}/></marker>)}</defs>
   {moves.map((m,i)=>{const a=squarePoint(m.uci.slice(0,2),black),b=squarePoint(m.uci.slice(2,4),black);return <line key={m.uci} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={colors[i]} strokeWidth={22-i*2} opacity=".42" markerEnd={`url(#popular-arrow-${i})`}/>;})}
   {moves.map((m,i)=>{const b=squarePoint(m.uci.slice(2,4),black);const duplicate=moves.slice(0,i).filter(n=>n.uci.slice(2,4)===m.uci.slice(2,4)).length;const y=Math.min(780,Math.max(20,b.y-30+duplicate*36));return <g key={m.uci} transform={`translate(${b.x},${y})`}><rect x="-34" y="-17" width="68" height="34" rx="17" fill="#142332" stroke={colors[i]} strokeWidth="2"/><text textAnchor="middle" dominantBaseline="central" fill={colors[i]} fontSize="22" fontFamily="Arial" fontWeight="700">{m.percent<1?m.percent.toFixed(1):Math.round(m.percent)}%</text></g>;})}
 </svg>;
}
