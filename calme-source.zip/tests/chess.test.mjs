import test from 'node:test';
import assert from 'node:assert/strict';
import { replay, cleanState, clockText } from '../lib/chess.ts';
import { readLines, LichessClient } from '../lib/lichess.ts';
test('roque standard et notation roi-tour donnent la même position', () => {
  const opening = 'e2e4 e7e5 g1f3 b8c6 f1c4 g8f6';
  assert.equal(
    replay(opening + ' e1g1').fen(),
    replay(opening + ' e1h1').fen(),
  );
});
test('promotion sous-promue et prise en passant', () => {
  assert.equal(
    replay('a7a8n', '7k/P7/8/8/8/8/8/7K w - - 0 1').get('a8').type,
    'n',
  );
  const b = replay('e2e4 a7a6 e4e5 d7d5 e5d6');
  assert.equal(b.get('d5'), undefined);
  assert.equal(b.get('d6').color, 'w');
});
test('position invalide rejetée et mat reconnu', () => {
  assert.throws(() => replay('e2e5'));
  assert.equal(replay('f2f3 e7e5 g2g4 d8h4').isCheckmate(), true);
});
test('aucune donnée sociale dans l’état nettoyé', () => {
  const state = cleanState({
    moves: '',
    wtime: 600000,
    btime: 600000,
    status: 'started',
    username: 'secret',
    rating: 2000,
    chat: 'private',
  });
  assert.equal(JSON.stringify(state).includes('secret'), false);
  assert.equal('rating' in state, false);
  assert.equal('chat' in state, false);
});
test('pendule ne descend pas sous zéro', () => {
  assert.equal(clockText(-100), '0:00');
  assert.equal(clockText(600000), '10:00');
});
test('flux fragmenté, lignes vides et dernier événement sans newline', async () => {
  const encoder = new TextEncoder();
  const chunks = [
    '\n{"type":"game',
    'State","moves":"e2e4"}\n\n',
    '{"type":"gameState","moves":"e2e4 e7e5"}',
  ];
  const response = new Response(
    new ReadableStream({
      start(c) {
        for (const chunk of chunks) c.enqueue(encoder.encode(chunk));
        c.close();
      },
    }),
  );
  const events = [];
  await readLines(response, (e) => events.push(e));
  assert.equal(events.length, 2);
  assert.equal(events[1].moves, 'e2e4 e7e5');
});
const state = { moves: '', wtime: 600000, btime: 600000, status: 'started' };
function setup() {
  const client = new LichessClient('fake', () => {});
  client.value = {
    connected: true,
    ready: true,
    searching: false,
    syncing: false,
    pending: false,
    error: '',
    game: {
      id: 'test',
      color: 'white',
      initialFen: 'startpos',
      rated: false,
      state,
      received: 0,
    },
  };
  return client;
}
test('coup incertain : aucun renvoi automatique et nouvelle position obligatoire', async () => {
  const client = setup();
  let calls = 0;
  client.request = async () => {
    calls++;
    throw new TypeError('offline');
  };
  await client.move('e2e4');
  assert.equal(calls, 1);
  assert.equal(client.value.pending, true);
  assert.equal(client.value.syncing, true);
  assert.equal(client.value.game.state.moves, '');
  await client.move('e2e4');
  assert.equal(calls, 1);
  client.accept({ ...state, moves: 'e2e4' }, true);
  assert.equal(client.value.pending, false);
  assert.equal(client.value.syncing, false);
  assert.equal(client.value.game.state.moves, 'e2e4');
  client.close();
});
test('coup non reçu : réessai manuel après resynchronisation', async () => {
  const client = setup();
  client.request = async () => new Response('{}');
  await client.move('e2e4');
  client.accept(state, true);
  assert.equal(client.value.pending, false);
  assert.match(client.value.error, /pas été confirmé/);
  client.close();
});
test('double clic et coups illégaux n’envoient pas plusieurs requêtes', async () => {
  const client = setup();
  let calls = 0,
    release;
  client.request = () => {
    calls++;
    return new Promise((r) => (release = r));
  };
  await client.move('e2e5');
  assert.equal(calls, 0);
  const first = client.move('e2e4');
  await client.move('d2d4');
  assert.equal(calls, 1);
  release(new Response('{}'));
  await first;
  client.close();
});
test('interdit les coups adverses ou pendant la reconnexion', async () => {
  const client = setup();
  let calls = 0;
  client.request = async () => {
    calls++;
    return new Response('{}');
  };
  client.value.syncing = true;
  await client.move('e2e4');
  client.value.syncing = false;
  client.value.game.color = 'black';
  await client.move('e2e4');
  assert.equal(calls, 0);
  client.close();
});

test('OAuth PKCE : challenge S256, portée minimale et retour sans paramètres', async () => {
  const { login, restoreToken } = await import('../lib/lichess.ts');
  const store = new Map();
  globalThis.sessionStorage = {
    getItem: (k) => store.get(k) ?? null,
    setItem: (k, v) => store.set(k, v),
    removeItem: (k) => store.delete(k),
  };
  let destination = '',
    cleaned = '';
  globalThis.location = {
    origin: 'https://example.github.io',
    pathname: '/chess/',
    search: '',
    assign: (url) => {
      destination = url;
    },
  };
  globalThis.history = {
    replaceState: (_a, _b, url) => {
      cleaned = url;
    },
  };
  await login();
  const url = new URL(destination),
    saved = JSON.parse(store.get('calme.oauth'));
  assert.equal(url.origin, 'https://lichess.org');
  assert.equal(url.searchParams.get('scope'), 'board:play');
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  const hash = await crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(saved.verifier),
  );
  assert.equal(
    url.searchParams.get('code_challenge'),
    Buffer.from(hash).toString('base64url'),
  );
  location.search = '?code=fake_code&state=' + saved.state;
  const previousFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    assert.equal(url, 'https://lichess.org/api/token');
    assert.equal(options.body.get('code_verifier'), saved.verifier);
    assert.equal(
      options.body.get('redirect_uri'),
      'https://example.github.io/chess/',
    );
    return new Response(JSON.stringify({ access_token: 'fake_token' }));
  };
  try {
    assert.equal(await restoreToken(), 'fake_token');
    assert.equal(cleaned, '/chess/');
    assert.equal(store.has('calme.oauth'), false);
  } finally {
    globalThis.fetch = previousFetch;
  }
});
test('OAuth refuse un retour dont le state ne correspond pas', async () => {
  const { login, restoreToken } = await import('../lib/lichess.ts');
  await login();
  location.search = '?code=fake&state=wrong';
  await assert.rejects(restoreToken(), /non vérifiée/);
});
