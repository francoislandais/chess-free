import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { popularMoves, squarePoint, loadPopular } from '../lib/explorer.ts';
const fen=new Chess().fen();
const move=(uci,n)=>({uci,white:n,draws:0,black:0});
test('classe par fréquence et calcule sur tout le corpus, pas seulement les trois coups affichés',()=>{
 const r=popularMoves({white:600,draws:100,black:300,moves:[move('e2e4',400),move('d2d4',300),move('g1f3',80),move('c2c4',100),move('b1c3',20)]},fen);
 assert.deepEqual(r.map(m=>m.percent),[40,30,10]);
 assert.equal(r[2].uci,'c2c4');
});
test('position absente et coups illégaux ne produisent pas de flèches',()=>{
 assert.deepEqual(popularMoves({white:0,draws:0,black:0,moves:[]},fen),[]);
 assert.deepEqual(popularMoves({white:10,draws:0,black:0,moves:[move('e2e5',10)]},fen),[]);
});
test('le roque de la base est ramené à la case du roi',()=>{
 assert.equal(popularMoves({white:10,draws:0,black:0,moves:[move('e1h1',10)]},'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')[0].uci,'e1g1');
});
test('coordonnées des flèches suivent le retournement',()=>{
 assert.deepEqual(squarePoint('e2',false),{x:450,y:650});
 assert.deepEqual(squarePoint('e2',true),{x:350,y:150});
});
test('requête rapide filtrée Elo, sans parties individuelles, cache par tranche',async()=>{
 const original=globalThis.fetch;
 globalThis.sessionStorage={getItem:()=>null};
 const requests=[];
 globalThis.fetch=async (url,options)=>{requests.push(new URL(url));assert.equal(options.credentials,'omit');return new Response(JSON.stringify({white:10,draws:0,black:0,moves:[move('e2e4',10)]}));};
 try {
  await loadPopular(fen,[1200,1400],new AbortController().signal);
  await loadPopular(fen,[1200,1400],new AbortController().signal);
  await loadPopular(fen,[2000],new AbortController().signal);
  assert.equal(requests.length,2);
  assert.equal(requests[0].hostname,'explorer.lichess.org');
  assert.equal(requests[0].searchParams.get('ratings'),'1200,1400');
  assert.equal(requests[0].searchParams.get('speeds'),'rapid');
  assert.equal(requests[0].searchParams.get('topGames'),'0');
 } finally {globalThis.fetch=original;delete globalThis.sessionStorage;}
});
