import { Chess } from 'chess.js';
export const ratingGroups = [0,1000,1200,1400,1600,1800,2000,2200,2500];
export type PopularMove = { uci: string; percent: number };
export function popularMoves(data: unknown, fen: string): PopularMove[] {
  const d = data as {white:number;draws:number;black:number;moves: {uci:string;white:number;draws:number;black:number}[]};
  const count = (v: {white:number;draws:number;black:number}) => {
    if (![v.white,v.draws,v.black].every(n => Number.isSafeInteger(n) && n >= 0)) throw new Error('Invalid counts');
    return v.white+v.draws+v.black;
  };
  const total = count(d);
  if (!Array.isArray(d.moves)) throw new Error('Invalid moves');
  if (!total) return [];
  const board = new Chess(fen);
  const legal = board.moves({verbose:true});
  return d.moves.map(m => {
    const move = legal.find(l => l.from+l.to+(l.promotion ?? '') === m.uci || (l.isKingsideCastle() || l.isQueensideCastle()) && l.from+(l.to[0] === 'g' ? 'h' : 'a')+l.to[1] === m.uci);
    return {uci: move ? move.from+move.to+(move.promotion ?? '') : '', count: count(m)};
  }).filter(m => m.uci && m.count > 0 && m.count <= total).sort((a,b) => b.count-a.count).slice(0,4).map(m => ({uci:m.uci,percent:100*m.count/total}));
}
export function squarePoint(square: string, black: boolean) {
  const file = square.charCodeAt(0)-97, rank = Number(square[1])-1;
  return {x:(black ? 7-file : file)*100+50,y:(black ? rank : 7-rank)*100+50};
}
const cache = new Map<string,PopularMove[]>();
let retryAfter = 0;
export async function loadPopular(fen: string, ratings: number[], signal: AbortSignal): Promise<PopularMove[]> {
  const key = fen+'|'+ratings.join(',');
  if(cache.has(key)) return cache.get(key)!;
  if(Date.now()<retryAfter) throw new Error('rate');
  const token = sessionStorage.getItem('calme.token');
  const query = new URLSearchParams({variant:'standard',speeds:'rapid',ratings:ratings.join(','),fen,moves:'4',topGames:'0',recentGames:'0'});
  const response = await fetch('https://explorer.lichess.org/lichess?'+query, {signal,credentials:'omit',headers:token ? {Authorization:`Bearer ${token}`} : {}});
  if(response.status===429) retryAfter=Date.now()+60000;
  if(!response.ok) throw new Error(response.status===401 ? 'auth' : 'unavailable');
  const result = popularMoves(await response.json(),fen);
  if(cache.size>=150) cache.delete(cache.keys().next().value!);
  cache.set(key,result);
  return result;
}
