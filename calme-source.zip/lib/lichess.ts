import { activeStatus, cleanState, replay, type GameState } from './chess.ts';
const HOST = 'https://lichess.org';
const TOKEN = 'calme.token';
const LAST = 'calme.lastGame';
const random = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(32)), (b) =>
    b.toString(16).padStart(2, '0'),
  ).join('');
const base64url = (buffer: ArrayBuffer) =>
  btoa(String.fromCharCode(...new Uint8Array(buffer)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
export async function login() {
  const verifier = random(),
    state = random(),
    redirect = location.origin + location.pathname;
  sessionStorage.setItem(
    'calme.oauth',
    JSON.stringify({ verifier, state, redirect, created: Date.now() }),
  );
  const challenge = base64url(
    await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)),
  );
  location.assign(
    `${HOST}/oauth?${new URLSearchParams({ response_type: 'code', client_id: 'calme-zen-chess', redirect_uri: redirect, scope: 'board:play', state, code_challenge: challenge, code_challenge_method: 'S256' })}`,
  );
}
export async function restoreToken() {
  const params = new URLSearchParams(location.search);
  if (params.has('code') || params.has('error')) {
    const saved = sessionStorage.getItem('calme.oauth');
    history.replaceState({}, '', location.pathname);
    sessionStorage.removeItem('calme.oauth');
    if (params.has('error')) throw new Error('Connexion Lichess annulée.');
    if (!saved) throw new Error('Connexion expirée. Recommencez.');
    const auth = JSON.parse(saved);
    if (
      params.get('state') !== auth.state ||
      Date.now() - auth.created > 600000
    )
      throw new Error('Connexion non vérifiée. Recommencez.');
    const response = await fetch(`${HOST}/api/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: params.get('code')!,
        code_verifier: auth.verifier,
        redirect_uri: auth.redirect,
        client_id: 'calme-zen-chess',
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!response.ok)
      throw new Error('Lichess n’a pas pu terminer la connexion.');
    const data = (await response.json()) as { access_token?: unknown };
    if (typeof data.access_token !== 'string')
      throw new Error('Autorisation manquante.');
    sessionStorage.setItem(TOKEN, data.access_token);
  }
  return sessionStorage.getItem(TOKEN);
}
export type Snapshot = {
  connected: boolean;
  ready: boolean;
  searching: boolean;
  syncing: boolean;
  pending: boolean;
  error: string;
  game?: {
    id: string;
    color: 'white' | 'black';
    initialFen: string;
    rated: boolean;
    state: GameState;
    received: number;
  };
};
export class ApiError extends Error {
  constructor(public status: number) {
    super(
      status === 401
        ? 'Votre connexion Lichess a expiré. Reconnectez-vous.'
        : status === 429
          ? 'Lichess demande une pause. Nouvelle tentative dans une minute.'
          : 'Lichess n’a pas confirmé cette action.',
    );
  }
}
export async function readLines(
  response: Response,
  onEvent: (event: Record<string, any>) => void,
  onActivity: () => void = () => {},
) {
  if (!response.body) throw new Error('Flux indisponible');
  const reader = response.body.getReader(),
    decoder = new TextDecoder();
  let buffer = '';
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      onActivity();
      buffer += decoder.decode(value, { stream: true });
      let index;
      while ((index = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, index).trim();
        buffer = buffer.slice(index + 1);
        if (line) onEvent(JSON.parse(line));
      }
      if (buffer.length > 1000000) throw new Error('Flux invalide');
    }
    buffer += decoder.decode();
    if (buffer.trim()) onEvent(JSON.parse(buffer));
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
export class LichessClient {
  value: Snapshot = {
    connected: true,
    ready: false,
    searching: false,
    syncing: false,
    pending: false,
    error: '',
  };
  private stopped = false;
  private uid = '';
  private event?: AbortController;
  private stream?: AbortController;
  private seek?: AbortController;
  private gameId = '';
  private cooldown = 0;
  private release?: () => void;
  private listeners = new Set<AbortController>();
  private pendingMove?: { uci: string; ply: number };
  private postBusy = false;
  constructor(
    private token: string,
    private change: (state: Snapshot) => void,
  ) {}
  emit(patch: Partial<Snapshot> = {}) {
    if (this.stopped) return;
    this.value = { ...this.value, ...patch };
    this.change(this.value);
  }
  private async request(path: string, options: RequestInit = {}) {
    if (Date.now() < this.cooldown) throw new ApiError(429);
    const response = await fetch(HOST + path, {
      ...options,
      headers: { Authorization: `Bearer ${this.token}`, ...options.headers },
      cache: 'no-store',
      signal: options.signal ?? AbortSignal.timeout(12000),
    });
    if (!response.ok) {
      if (response.status === 429) this.cooldown = Date.now() + 60000;
      if (response.status === 401) {
        sessionStorage.removeItem(TOKEN);
        this.emit({ connected: false, ready: false });
      }
      throw new ApiError(response.status);
    }
    return response;
  }
  private async sleep(ms: number) {
    await new Promise<void>((resolve) => {
      const id = setTimeout(resolve, ms);
      const t = setInterval(() => {
        if (this.stopped) {
          clearTimeout(id);
          clearInterval(t);
          resolve();
        }
      }, 250);
      setTimeout(() => clearInterval(t), ms + 1);
    });
  }
  async start() {
    try {
      const account = (await (await this.request('/api/account')).json()) as {
        id: string;
      };
      this.uid = account.id;
      if (this.stopped) return;
      if (!navigator.locks)
        throw new Error(
          'Ce navigateur ne permet pas de sécuriser les sessions simultanées. Utilisez un navigateur récent.',
        );
      await new Promise<void>((resolve, reject) => {
        navigator.locks
          .request(`calme:${this.uid}`, { ifAvailable: true }, async (lock) => {
            if (!lock) {
              reject(
                new Error(
                  'Calme est déjà ouvert dans un autre onglet. Fermez-le puis rechargez ici.',
                ),
              );
              return;
            }
            if (this.stopped) {
              resolve();
              return;
            }
            await new Promise<void>((release) => {
              this.release = release;
              resolve();
            });
          })
          .catch(reject);
      });
      if (this.stopped) return;
      await this.resume();
      void this.events();
    } catch (e) {
      this.emit({ error: this.message(e), ready: false });
    }
  }
  private message(e: unknown) {
    return e instanceof ApiError
      ? e.message
      : e instanceof Error &&
          !(e instanceof TypeError) &&
          e.name !== 'AbortError' &&
          e.name !== 'TimeoutError'
        ? e.message
        : 'Connexion interrompue. Vérification de la partie en cours…';
  }
  async resume() {
    const data = (await (
      await this.request('/api/account/playing')
    ).json()) as {
      nowPlaying?: Array<{
        speed: string;
        variant?: { key: string };
        gameId: string;
      }>;
    };
    if (this.stopped) return;
    const game = (data.nowPlaying ?? []).find(
      (g: any) => g.speed === 'rapid' && g.variant?.key === 'standard',
    );
    if (game) {
      this.attach(game.gameId);
      return;
    }
    const last = sessionStorage.getItem(LAST);
    if (last && !this.gameId) this.attach(last);
  }
  private async events() {
    let attempts = 0;
    while (!this.stopped) {
      const ctrl = new AbortController();
      this.event = ctrl;
      let activity = Date.now();
      const watchdog = setInterval(() => {
        if (Date.now() - activity > 25000) ctrl.abort();
      }, 5000);
      try {
        const response = await this.request('/api/stream/event', {
          signal: ctrl.signal,
        });
        if (this.stopped) break;
        attempts = 0;
        this.emit({ ready: true });
        await readLines(
          response,
          (event) => {
            if (event.type === 'gameStart')
              void this.resume().catch((e) =>
                this.emit({ error: this.message(e) }),
              );
          },
          () => {
            activity = Date.now();
          },
        );
      } catch (e) {
        if (!this.stopped) this.emit({ error: this.message(e) });
      } finally {
        clearInterval(watchdog);
      }
      if (this.stopped) break;
      this.seek?.abort();
      this.emit({ ready: false, searching: false });
      await this.sleep(
        Math.max(
          this.cooldown - Date.now(),
          Math.min(15000, 1000 * 2 ** attempts++),
        ),
      );
      if (this.stopped) break;
      await this.resume().catch(() => {});
    }
  }
  private attach(id: string) {
    if (this.stopped || this.gameId === id) return;
    this.stream?.abort();
    this.gameId = id;
    sessionStorage.setItem(LAST, id);
    this.seek?.abort();
    this.emit({ searching: false, syncing: true, error: '' });
    void this.gameLoop(id);
  }
  private async gameLoop(id: string) {
    let attempts = 0;
    while (!this.stopped && this.gameId === id) {
      const ctrl = new AbortController();
      this.stream = ctrl;
      let activity = Date.now();
      const watchdog = setInterval(() => {
        if (Date.now() - activity > 20000) ctrl.abort();
      }, 4000);
      try {
        const response = await this.request(`/api/board/game/stream/${id}`, {
          signal: ctrl.signal,
        });
        attempts = 0;
        await readLines(
          response,
          (event) => {
            if (this.stopped || this.gameId !== id) return;
            if (event.type === 'gameFull') {
              if (event.variant?.key !== 'standard' || event.speed !== 'rapid')
                throw new Error(
                  'Cette version prend en charge les parties rapides classiques uniquement.',
                );
              const color =
                event.white?.id === this.uid
                  ? 'white'
                  : event.black?.id === this.uid
                    ? 'black'
                    : undefined;
              if (!color)
                throw new Error('Ce compte ne participe pas à cette partie.');
              this.emit({
                game: {
                  id,
                  color,
                  initialFen: event.initialFen || 'startpos',
                  rated: event.rated === true,
                  state: cleanState(event.state),
                  received: performance.now(),
                },
              });
              this.accept(event.state, true);
            } else if (event.type === 'gameState' && this.value.game)
              this.accept(event, false);
            // chatLine, identities, ratings and social events are deliberately discarded.
          },
          () => {
            activity = Date.now();
          },
        );
        if (this.value.game && !activeStatus(this.value.game.state.status))
          break;
      } catch (e) {
        if (e instanceof ApiError && (e.status === 404 || e.status === 403)) {
          sessionStorage.removeItem(LAST);
          this.gameId = '';
          this.emit({
            error: 'Cette partie n’est plus accessible.',
            syncing: false,
          });
          break;
        }
        if (!this.stopped) this.emit({ error: this.message(e) });
      } finally {
        clearInterval(watchdog);
      }
      if (this.stopped || this.gameId !== id) break;
      this.emit({ syncing: true });
      await this.sleep(
        Math.max(
          this.cooldown - Date.now(),
          Math.min(10000, 1000 * 2 ** attempts++),
        ),
      );
    }
  }
  private accept(raw: Record<string, unknown>, full: boolean) {
    const game = this.value.game;
    if (!game) return;
    const state = cleanState(raw);
    replay(state.moves, game.initialFen);
    let error = '';
    if (this.pendingMove) {
      const moves = state.moves.trim().split(/\s+/).filter(Boolean);
      if (moves.length > this.pendingMove.ply || (full && !this.postBusy)) {
        if (moves.length === this.pendingMove.ply)
          error =
            'Le dernier coup n’a pas été confirmé. Vous pouvez le rejouer.';
        this.pendingMove = undefined;
      }
    }
    if (!activeStatus(state.status)) {
      sessionStorage.removeItem(LAST);
      this.pendingMove = undefined;
    }
    this.emit({
      game: { ...game, state, received: performance.now() },
      syncing: false,
      pending: !!this.pendingMove,
      error,
    });
  }
  async search(time: number, increment: number, rated: boolean) {
    if (
      this.stopped ||
      !this.value.ready ||
      this.value.searching ||
      (this.value.game && activeStatus(this.value.game.state.status))
    )
      return;
    if (
      ![
        [10, 0],
        [10, 5],
        [15, 10],
      ].some(([t, i]) => t === time && i === increment)
    )
      return;
    this.stream?.abort();
    this.gameId = '';
    this.emit({ game: undefined, error: '', searching: true });
    const ctrl = new AbortController();
    this.seek = ctrl;
    try {
      await this.resume();
      if (this.gameId || this.stopped || ctrl.signal.aborted) return;
      const response = await this.request('/api/board/seek', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          time: String(time),
          increment: String(increment),
          rated: String(rated),
          variant: 'standard',
        }),
        signal: ctrl.signal,
      });
      await readLines(response, () => {});
    } catch (e) {
      if (!ctrl.signal.aborted) this.emit({ error: this.message(e) });
    } finally {
      if (!this.stopped) {
        this.emit({ searching: false });
        await this.resume().catch((e) => this.emit({ error: this.message(e) }));
      }
    }
  }
  cancel() {
    this.seek?.abort();
    this.emit({ searching: false });
    void this.resume().catch((e) => this.emit({ error: this.message(e) }));
  }
  async move(uci: string) {
    const game = this.value.game;
    if (
      !game ||
      this.value.syncing ||
      this.value.pending ||
      this.postBusy ||
      !activeStatus(game.state.status)
    )
      return;
    const board = replay(game.state.moves, game.initialFen);
    if (board.turn() !== game.color[0]) return;
    try {
      board.move({
        from: uci.slice(0, 2),
        to: uci.slice(2, 4),
        promotion: uci[4],
      });
    } catch {
      return;
    }
    this.pendingMove = {
      uci,
      ply: game.state.moves.trim().split(/\s+/).filter(Boolean).length,
    };
    this.postBusy = true;
    this.emit({ pending: true, error: '' });
    try {
      await this.request(`/api/board/game/${game.id}/move/${uci}`, {
        method: 'POST',
      });
    } catch (e) {
      this.emit({ error: this.message(e) });
    } finally {
      this.postBusy = false;
      if (this.pendingMove) {
        this.emit({ syncing: true });
        this.stream?.abort();
      }
    }
  }
  async action(action: 'resign' | 'abort' | 'draw/yes' | 'draw/no') {
    const game = this.value.game;
    if (
      !game ||
      this.postBusy ||
      this.value.pending ||
      this.value.syncing ||
      !activeStatus(game.state.status)
    )
      return;
    this.postBusy = true;
    this.emit({ pending: true, error: '' });
    try {
      await this.request(`/api/board/game/${game.id}/${action}`, {
        method: 'POST',
      });
    } catch (e) {
      this.emit({ error: this.message(e) });
    } finally {
      this.postBusy = false;
      this.emit({ pending: false, syncing: true });
      this.stream?.abort();
    }
  }
  reconnect() {
    if (this.value.game && activeStatus(this.value.game.state.status)) {
      this.emit({ syncing: true });
      this.stream?.abort();
    }
    this.event?.abort();
  }
  close() {
    this.stopped = true;
    this.event?.abort();
    this.stream?.abort();
    this.seek?.abort();
    this.listeners.forEach((c) => c.abort());
    this.release?.();
  }
}
export function forgetToken() {
  sessionStorage.removeItem(TOKEN);
}
