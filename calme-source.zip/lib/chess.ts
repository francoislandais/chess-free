import { Chess, type Square } from 'chess.js';
export type GameState = {
  moves: string;
  wtime: number;
  btime: number;
  status: string;
  winner?: 'white' | 'black';
  wdraw?: boolean;
  bdraw?: boolean;
  expiration?: { idleMillis: number; millisToMove: number };
};
export const activeStatus = (status: string) =>
  status === 'started' || status === 'created';
export function replay(moves: string, initialFen = 'startpos') {
  const board = new Chess(initialFen === 'startpos' ? undefined : initialFen);
  for (const uci of moves.trim().split(/\s+/).filter(Boolean)) {
    let to = uci.slice(2, 4);
    // Board streams may use king-to-rook castling notation, even in standard chess.
    const from = uci.slice(0, 2) as Square;
    if (
      board.get(from)?.type === 'k' &&
      board.get(to as Square)?.type === 'r' &&
      board.get(to as Square)?.color === board.turn()
    )
      to = (to[0] === 'h' ? 'g' : 'c') + from[1];
    board.move({ from, to: to as Square, promotion: uci[4] });
  }
  return board;
}
export function cleanState(input: Record<string, unknown>): GameState {
  if (
    typeof input.moves !== 'string' ||
    typeof input.wtime !== 'number' ||
    typeof input.btime !== 'number' ||
    typeof input.status !== 'string'
  )
    throw new Error('État de partie incomplet.');
  return {
    moves: input.moves,
    wtime: input.wtime,
    btime: input.btime,
    status: input.status,
    winner:
      input.winner === 'white' || input.winner === 'black'
        ? input.winner
        : undefined,
    wdraw: input.wdraw === true,
    bdraw: input.bdraw === true,
    expiration: cleanExpiration(input.expiration),
  };
}
export function resultText(state: GameState, color: 'white' | 'black') {
  if (state.status === 'aborted') return 'Partie annulée';
  if (state.status === 'draw' || state.status === 'stalemate')
    return 'Partie nulle';
  if (state.winner)
    return state.winner === color
      ? 'Vous avez gagné.'
      : 'Partie terminée — défaite';
  return 'Partie terminée';
}
export function clockText(ms: number) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function cleanExpiration(input: unknown): GameState['expiration'] {
  if (!input || typeof input !== 'object') return;
  const v = input as Record<string, unknown>;
  if (typeof v.idleMillis !== 'number' || typeof v.millisToMove !== 'number')
    return;
  return { idleMillis: v.idleMillis, millisToMove: v.millisToMove };
}
