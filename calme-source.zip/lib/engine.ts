export const engineLevels = [
  { elo: 1320, time: 90 },
  { elo: 1500, time: 180 },
  { elo: 1800, time: 350 },
  { elo: 2200, time: 650 },
];

export class LocalEngine {
  private worker: Worker;
  private initialized: Promise<void>;
  private resolveMove: ((move: string) => void) | null = null;
  private rejectMove: ((reason?: unknown) => void) | null = null;

  constructor() {
    this.worker = new Worker('./stockfish/stockfish.js');
    this.initialized = new Promise((resolve) => {
      const ready = (event: MessageEvent<string>) => {
        if (event.data !== 'uciok') return;
        this.worker.removeEventListener('message', ready);
        resolve();
      };
      this.worker.addEventListener('message', ready);
      this.worker.postMessage('uci');
    });
    this.worker.addEventListener('message', (event: MessageEvent<string>) => {
      const match = /^bestmove ([a-h][1-8][a-h][1-8][qrbn]?)/.exec(event.data);
      if (!match || !this.resolveMove) return;
      this.resolveMove(match[1]);
      this.resolveMove = null;
      this.rejectMove = null;
    });
  }

  ready() {
    return this.initialized;
  }

  async bestMove(fen: string, level: number) {
    await this.initialized;
    const setting = engineLevels[level];
    this.worker.postMessage('setoption name UCI_LimitStrength value true');
    this.worker.postMessage(`setoption name UCI_Elo value ${setting.elo}`);
    this.worker.postMessage(`position fen ${fen}`);
    return new Promise<string>((resolve, reject) => {
      this.resolveMove = resolve;
      this.rejectMove = reject;
      this.worker.postMessage(`go movetime ${setting.time}`);
    });
  }

  stop() {
    this.worker.postMessage('stop');
  }

  close() {
    this.rejectMove?.(new Error('Engine stopped'));
    this.resolveMove = null;
    this.rejectMove = null;
    this.worker.postMessage('quit');
    this.worker.terminate();
  }
}
